{**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 *}
{extends file=$layout}

{block name='head_microdata_special'}
  {include file='_partials/microdata/product-list-jsonld.tpl' listing=$listing}
{/block}

{block name='content'}
  <section id="main">

    {* 1. PRZYWRÓCONY NAGŁÓWEK KATEGORII (np. "Niskokaloryczna żywność") *}
    {block name='product_list_header'}
      <div class="wk-category-header">
          <h1 id="js-product-list-header" class="h1">{$listing.label}</h1>
      </div>
    {/block}

    {block name='subcategory_list'}
      {if isset($subcategories) && $subcategories|@count > 0}
        {include file='catalog/_partials/subcategories.tpl' subcategories=$subcategories}
      {/if}
    {/block}

    <section id="products">
      {if $listing.products|count}

        {* 2. PRZYWRÓCONA GÓRNA BELKA (Sortowanie, ilość produktów) *}
        {* Jest niezbędna, aby poprawnie działały style CSS dla listy *}
        <div id="js-product-list-top">
          {block name='product_list_top'}
            {include file='catalog/_partials/products-top.tpl' listing=$listing}
          {/block}
        </div>

        {block name='product_list_active_filters'}
          <div class="hidden-sm-down">
            {$listing.rendered_active_filters nofilter}
          </div>
        {/block}

        {* 3. WŁAŚCIWA LISTA PRODUKTÓW (To tutaj ładuje się siatka ze zdjęcia) *}
        <div id="js-product-list">
          {include file='catalog/_partials/products.tpl' listing=$listing}
        </div>

        {* 4. DOLNA BELKA (Paginacja) *}
        <div id="js-product-list-bottom">
          {block name='product_list_bottom'}
            {include file='catalog/_partials/products-bottom.tpl' listing=$listing}
          {/block}
        </div>

      {else}
        {* Brak produktów *}
        <div id="js-product-list-top"></div>
        <div id="js-product-list">
          {include file='errors/not-found.tpl'}
        </div>
      {/if}
    </section>

    {hook h="displayFooterCategory"}

  </section>
{/block}